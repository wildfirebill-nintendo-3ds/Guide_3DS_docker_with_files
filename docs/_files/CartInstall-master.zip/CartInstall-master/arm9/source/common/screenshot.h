#pragma once

void CreateScreenshot();
